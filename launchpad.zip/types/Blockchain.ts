export interface Blockchain {
  id: number;
  name: string;
  rpc_url: string;
  explorer_url: string;
  image: string;
  status: string;
}
