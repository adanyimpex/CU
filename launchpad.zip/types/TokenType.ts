export default {
  BasicToken: "Basic Token",
  BurnableToken: "Burnable Token",
  MintableToken: "Mintable Token",
  MemeToken: "Meme Coin",
  TaxToken: "Tax Token",
} as const;
