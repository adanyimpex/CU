declare module "@splidejs/react-splide";

type ValueOf<T> = T[keyof T];
